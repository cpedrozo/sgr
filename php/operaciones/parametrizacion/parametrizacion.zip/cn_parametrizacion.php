<?php
class cn_parametrizacion extends sgr_cn
{
  public static function cargarpropietario()
  {
    if ($this->dep('dr_propietario')->tabla('dt_propietario')->hay_cursor()) {
      $datos = $this->dep('dr_propietario')->tabla('dt_propietario')->get();
      $form->set_datos($datos);
    }
  }

  function guardarpropietario()
  {
    $this->dep('dr_propietario')->sincronizar();
    $this->dep('dr_propietario')->resetear();
  }

  function resetpropietario()
  {
    $this->dep('dr_propietario')->resetear();
  }

  function modifpropietario()
  {
    $this->dep('dr_propietario')->tabla('dt_propietario')->set($datos);
  }

  public static function seleccionpropietario($seleccion)
  {

  $this->dep('dr_propietario')->tabla('dt_propietario')->cargar($seleccion);
  $id_fila = $this->dep('dr_propietario')->tabla('dt_propietario')->get_id_fila_condicion($seleccion)[0];
  $this->dep('dr_propietario')->tabla('dt_propietario')->set_cursor($id_fila);
  }

  function borrarpropietario()
  {
    $this->dep('dr_propietario')->tabla('dt_propietario')->cargar($seleccion);
    $id_fila = $this->dep('dr_propietario')->tabla('dt_propietario')->get_id_fila_condicion($seleccion)[0];
    $this->dep('dr_propietario')->tabla('dt_propietario')->set_cursor($id_fila);
    $this->dep('dr_propietario')->tabla('dt_propietario')->eliminar_fila($id_fila);
  }

  }

?>
