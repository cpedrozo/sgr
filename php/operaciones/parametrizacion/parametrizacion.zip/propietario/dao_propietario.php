<?php

class dao_propietario
{
  static function get_datos()
  {
  	$sql = "SELECT * FROM sgr.propietario";
  	$datos = consultar_fuente($sql);
    return $datos;
  }
}
?>
