<?php

require_once('operaciones/parametrizacion/propietario/dao_propietario.php');
require_once('operaciones/parametrizacion/cn_parametrizacion.php');

class ci_propietario extends sgr_ci
{

	function conf__cuadro($cuadro)
	{
		$datos = dao_propietario::get_datos();
		$cuadro->set_datos($datos);
	}

	function conf__form($form)
	{
		//cn_parametrizacion::cargarpropietario();
	}

	function evt__nuevo()
	{
		$this->set_pantalla('pant_edicion');
	}

	function evt__procesar()
	{
		try{
			guardarpropietario();
			$this->set_pantalla('pant_inicial');
		}catch (toba_error_db $e) {
			resetpropietario();
			ei_arbol(array('$e->get_sqlstate():' => $e->get_mensaje_log()));
			toba::notificacion()->agregar('No se guardo', 'error');
		}
	}

	function evt__form__modificacion($datos)
	{
		modifpropietario();
	}

	function evt__cuadro__seleccion($seleccion)
	{
		//ei_arbol(array('$e->get_sqlstate():' => $e->$seleccion));
		cn_parametrizacion::seleccionpropietario($seleccion);

		$this->set_pantalla('pant_edicion');
	}

	function evt__cuadro__borrar($seleccion)
	{
		borrarpropietario();
		$this->evt__procesar();
	}
}
?>
